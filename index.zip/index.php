<!DOCTYPE html>
<html lang="en">
<head>
  <title>UDISE FORMAT 1</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style type="text/css">
  			body{
				font-size: 8px;
				}table, th, td {
				border: 1px solid #d6d6c2;
				border-collapse: collapse;
				padding: 0.3em;
				text-align: left;
				}table {
				width: 100%;
				}#bor{
				border: 1px solid black;
				padding: 1px;
				}
</style>
  </style>
</head>
<body>

<div class="container">
  
  
    <div class="row">

      
      <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="border: none; width: 50%;">
       <table style="border: none !important;">
       		<tr>
       			<td style="border: none !important;">Generated On : 20 May 2021 08:45:52 AM</td>
       		</tr>
       </table>
      </div>

      <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="border: none; width: 50%;">
       <table style="border: none !important;">
       		<tr>
       			<td style="text-align: right; border: none;">Certification Status : Not Certified</td>
       		</tr>
       </table>
      </div>

      <div class="col-md-12 col-sm-12 col-xs-12" align="center"><h4><b>SCHOOL REPORT CARD (2022-23)</b></h4></div>


      
      <div class="col-md-12 col-sm-12 col-xs-12" id="bor">
	        <table>


	  			<tr>

	  				<th colspan="2"><b>UDISE Code</b></th>
	  				<th colspan="2"><b>04 01 09 00 203</b></th>
	  				<th colspan="2"><b>School Name</b></th>
	  				<th colspan="5"><b>SRI GURU GOBIND SINGH SR.SEC -35</b></th>


	  			</tr>
	  		
	  			<tr>

	  				<td colspan="2">State</td>
	  				<td colspan="2">Chandigarh</td>
	  				<td colspan="2">District</td>
	  				<td colspan="2">CHANDIGARH</td>
	  				<td colspan="1">Block</td>
	  				<td colspan="2">BLOCK 1</td>

	  			</tr>
	  			<tr>

	  				<td colspan="2">Rural / Urban</td>
	  				<td colspan="2">2-Urban</td>
	  				<td colspan="2">Cluster</td>
	  				<td colspan="5">CLUSTER 9</td>
	  				
	  			</tr>

	  			<tr>

	  				<td colspan="2">Ward</td>
	  				<td colspan="2">SECTOR 35</td>
	  				<td colspan="2">Mohalla</td>
	  				<td colspan="2">SECTOR 35</td>
	  				<td colspan="1">Pincode</td>
	  				<td colspan="2">160022</td>

	  			</tr>

	  			<tr>

	  				<td colspan="2">Panchayat</td>
	  				<td colspan="2">NA</td>
	  				<td colspan="2">City</td>
	  				<td colspan="2">Chandigarh</td>
	  				<td colspan="1">Municipality</td>
	  				<td colspan="2">Chd. Municipality Corporation</td>

	  			</tr>

	  			<tr>

	  				<td colspan="2">Assembly Const.</td>
	  				<td colspan="2">Chandigarh</td>
	  				<td colspan="7">Parl. Constituency</td>

	  			</tr>
	  		</table>
  	  </div>


  	  
  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 50%;">
	        <table>

	  		
	  			<tr>
	  				<td colspan="3">School Category</td>
	  				<td colspan="3">3 - Pr. with Up.Pr. sec. and H.Sec.</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">School Management</td>
	  				<td colspan="3">4-Government Aided</td>
	  			</tr>

	  			<tr>

	  				<td colspan="3">School Type </td>
	  				<td colspan="3">3-Co-educational</td>


	  			</tr>

	  			<tr>
	  				<td colspan="3">Lowest & Highest Class</td>
	  				<td colspan="3">1 - 12</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Pre Primary</td>
	  				<td colspan="3">1-Yes</td>
	  			</tr>
	  		</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 30%; float: left;">
	        <table>

	  		
	  			<tr>
	  				<td colspan="6" style="text-align: center !important;"><b>Medium of Instruction</b></td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Medium 1</td>
	  				<td colspan="3">19-English</td>
	  			</tr>

	  			<tr>

	  				<td colspan="3">Medium 2</td>
	  				<td colspan="3">04-Hindi</td>


	  			</tr>

	  			<tr>
	  				<td colspan="3">Medium 3</td>
	  				<td colspan="3">13-Punjabi</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Medium 4</td>
	  				<td colspan="3"></td>
	  			</tr>
	  		</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 20%; float: left;">
	        <table>

	  		
	  			<tr>
	  				<td colspan="6" style="text-align: center !important;"><b>Visit of school for / by</b></td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Acad. Inspections</td>
	  				<td colspan="3">2</td>
	  			</tr>

	  			<tr>

	  				<td colspan="3">CRC Coordinator </td>
	  				<td colspan="3">2</td>


	  			</tr>

	  			<tr>
	  				<td colspan="3">Block Level Officers</td>
	  				<td colspan="3">1</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">State/District Officers </td>
	  				<td colspan="3">1</td>
	  			</tr>
	  		</table>
  	  </div>




  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 34%; float: left;">
	        <table>

	  		
	  			<tr>
	  				<td colspan="2">Year of Establishment </td>
	  				<td colspan="9" style="border-right: none;"></td>
	  				<td style="text-align: right !important; border-left: none;">1956</td>
	  			</tr>

	  			<tr>
	  				<td colspan="2">Year of Recognition-Pri.  </td>
	  				<td colspan="9" style="border-right: none;"></td>
	  				<td style="text-align: right !important; border-left: none;">1956</td>
	  			</tr>

	  			<tr>
	  				<td colspan="2">Year of Recognition-Upr.Pri. </td>
	  				<td colspan="9" style="border-right: none;"></td>
	  				<td style="text-align: right !important; border-left: none;">1956</td>
	  			</tr>

	  			<tr>
	  				<td colspan="2">Year of Recognition-Sec. </td>
	  				<td colspan="9" style="border-right: none;"></td>
	  				<td style="text-align: right !important; border-left: none;">1956</td>
	  			</tr>

	  			<tr>
	  				<td colspan="2">Year of Recognition-Higher Sec. </td>
	  				<td colspan="9" style="border-right: none;"></td>
	  				<td style="text-align: right !important; border-left: none;">1956</td>
	  			</tr>

	  			<tr>
	  				<td colspan="12">&nbsp;</td>
	  			</tr>

	  			<tr>
	  				<td colspan="">Affiliation Board-Sec</td>
	  				<td style="border-left: none; border-right: none;">1-CBSE</td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  			</tr>

	  			<tr>
	  				<td colspan="">Affiliation Board-HSec</td>
	  				<td style="border-left: none; border-right: none;">1-CBSE</td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  			</tr>
	  		</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 32%; float: left;">
	        <table>

	  		
	  			<tr>
	  				<td colspan="3">Is this a Shift School? </td>
	  				<td colspan="3">2-No</td>
	  			</tr>

	  			<tr>
	  				<td colspan="1">Building Status</td>
	  				<td colspan="1" style="border-right: none;">1-Private</td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  				<td style="border-left: none; border-right: none;"></td>
	  			</tr>
	  			
	  			<tr>
	  				<td colspan="3">Boundary wall</td>
	  				<td colspan="3">1-Pucca</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">No.of Building Blocks </td>
	  				<td colspan="3">2</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Pucca Building Blocks </td>
	  				<td colspan="3">2</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Is Special School for CWSN?</td>
	  				<td colspan="3">2-No</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Availability of Ramps</td>
	  				<td colspan="3">2-No</td>
	  			</tr>

	  			<tr>
	  				<td colspan="3">Availability of Handrails</td>
	  				<td colspan="3"></td>
	  			</tr>
	  		</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 34%; float: left;">
	        <table>
		  			<tr>
		  				<td colspan="3">Anganwadi At Premises</td>
		  				<td colspan="3">2-No</td>
		  			</tr>

		  			<tr>
		  				<td colspan="3">Anganwadi Boys</td>
		  				<td colspan="3">0</td>
		  			</tr>
		  			
		  			<tr>
		  				<td colspan="3">Anganwadi Girls</td>
		  				<td colspan="3">0</td>
		  			</tr>

		  			<tr>
		  				<td colspan="3">Anganwadi Worker</td>
		  				<td colspan="3">NA</td>
		  			</tr>

		  			<tr>
		  				<td colspan="3">Residential Schoo</td>
		  				<td colspan="3"></td>
		  			</tr>

		  			<tr>
		  				<td colspan="1">Residential Type</td>
		  				<td colspan="1" style="border-right: none;">2-No</td>
		  				<td style="border-left: none; border-right: none;"></td>
		  				<td style="border-left: none; border-right: none;"></td>
		  				<td style="border-left: none; border-right: none;"></td>
		  				<td style="border-left: none; border-right: none;"></td>
		  			</tr>

		  			<tr>
		  				<td colspan="3">Minority School</td>
		  				<td colspan="3">1-Yes</td>
		  			</tr>

		  			<tr>
		  				<td colspan="3">Approachable By All Weather Road</td>
		  				<td colspan="3">1-Yes</td>
		  			</tr>

	  		</table>
  	  </div>




  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 34%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td style="text-align: center;"><b>Toilets</b></td>
  	  			<td style="text-align: center;"><b>Boys</b></td>
  	  			<td style="text-align: center;"><b>Girls</b></td>
  	  		</tr>

  	  		<tr>
  	  			<td>Total</td>
  	  			<td style="text-align: right !important;">11</td>
  	  			<td style="text-align: right !important;">11</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Functional</td>
  	  			<td style="text-align: right !important;">11</td>
  	  			<td style="text-align: right !important;">11</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Func. CWSN Friendly</td>
  	  			<td style="text-align: right !important;">0</td>
  	  			<td style="text-align: right !important;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Urinal</td>
  	  			<td style="text-align: right !important;">8</td>
  	  			<td style="text-align: right !important;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Handwash Near Toile</td>
  	  			<td colspan="2" style="text-align: right !important;">1-Yes</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Handwash Facility for Meal</td>
  	  			<td colspan="2" style="text-align: right !important;">7</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="3">&nbsp;</td>
  	  		</tr>
  	  	</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 32%; float: left;">

  	  	<table>
  	  		<tr>
  	  			<td><b>Total Class Rooms</b></td>
  	  			<td style="text-align: right;"><b>58</b></td>
  	  		</tr>

  	  		<tr>
  	  			<td>In Good Condition </td>
  	  			<td style="text-align: right;">58</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Needs Minor Repair</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Needs Major Repair</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">&nbsp;</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Other Rooms</td>
  	  			<td style="text-align: right;">16</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Library Availability</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Separate Room for HM</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>
  	  	</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 34%; float: left;">

  	  	<table>
  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Drinking Water Available</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Drinking Water Functional</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Rain Water Harvesting</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">2-No</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Playground Available</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Furniture Availability</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">2300</td>
  	  		</tr>

  	  		<tr>
  	  			<td>Electricity Availability</td>
  	  			<td style="text-align: left; border-right: none;">1-Yes</td>
  	  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
		  			<td style="border-left: none; border-right: none;"></td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Solar Panel</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2" style="border-right: none;">Medical checkups</td>
  	  			<td style="border-left: none; border-right: none;" colspan="9"></td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>
  	  	</table>
  	  </div>




  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 55%; float: left;">
  	  	<table>

  	  		<tr>
  	  			<td colspan="9" style="text-align: center;"><b>Digital Facilities (Functional)</b></td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">ICT Lab</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  			<td colspan="2">Internet</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  			<td colspan="2">Desktop</td>
  	  			<td style="text-align: right;">35</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Laptop</td>
  	  			<td style="text-align: right;">1</td>
  	  			<td colspan="2">Tablet</td>
  	  			<td style="text-align: right;">0</td>
  	  			<td colspan="2">Printer</td>
  	  			<td style="text-align: right;">8</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Projector</td>
  	  			<td style="text-align: right;">2</td>
  	  			<td colspan="2">DTH</td>
  	  			<td style="text-align: right;">2-No</td>
  	  			<td colspan="2">DigiBoard</td>
  	  			<td style="text-align: right;">8</td>
  	  		</tr>

  	  	</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 45%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td colspan="9"><b>No.of Students Received (DCF 5.1 , 5.2)</b></td>
  	  			<td>Primary</td>
  	  			<td>Up.Primary</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="9">Free text books</td>
  	  			<td style="text-align: right;">0</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="9">Transport</td>
  	  			<td style="text-align: right;">0</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="9">Free uniform</td>
  	  			<td style="text-align: right;">0</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>
  	  	</table>
  	  </div>




  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 65%; float: left;">
  	  		<table>
  	  			<tr>
  	  				<td colspan="6" style="text-align: center;"><b>RTE Information & Management</b></td>
  	  			</tr>

  	  			<tr>
  	  				<td>SMC Exists</td>
  	  				<td style="text-align: right;">1-Yes</td>
  	  				<td>SMC & SMDC Same </td>
  	  				<td style="text-align: right;">2-No</td>
  	  				<td>SMDC Constituted</td>
  	  				<td style="text-align: right;">1-Yes</td>
  	  			</tr>

  	  			<tr>
  	  				<td>Text Books Received</td>
  	  				<td style="text-align: right;">1-Yes</td>
  	  				<td>Special Training</td>
  	  				<td style="text-align: right;">2-No</td>
  	  				<td>Material for Training</td>
  	  				<td style="text-align: right;">2-No</td>
  	  			</tr>

  	  			<tr>
  	  				<td colspan="6" style="text-align: center;"><b>Grants Details under Samagra Shiksha (DCF Sl. No. 8.1)</b></td>
  	  			</tr>

  	  			<tr>
  	  				<td>Grants Receipt</td>
  	  				<td style="text-align: right;" colspan="2">1.6753608E7</td>
  	  				<td>Grants Expenditure</td>
  	  				<td style="text-align: right;" colspan="2">1.6753608E7</td>
  	  			</tr>
  	  		</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 35%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td colspan="2" style="text-align: center;"><b>RTE Information</b></td>
  	  			<td>Pri.</td>
  	  			<td>Up.Pr</td>
  	  			<td>Sec.</td>
  	  			<td>H.Sec</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Instructional days</td>
  	  			<td style="text-align: right;">235</td>
  	  			<td style="text-align: right;">235</td>
  	  			<td style="text-align: right;">235</td>
  	  			<td style="text-align: right;">235</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Avg.School hrs.Std.</td>
  	  			<td style="text-align: right;">0.0</td>
  	  			<td style="text-align: right;">0.0</td>
  	  			<td style="text-align: right;">0.0</td>
  	  			<td style="text-align: right;">0.0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Avg.School hrs.Tch.</td>
  	  			<td style="text-align: right;">6.0</td>
  	  			<td style="text-align: right;">6.0</td>
  	  			<td style="text-align: right;">6.0</td>
  	  			<td style="text-align: right;">6.0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">CCE</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  			<td style="text-align: right;">1-Yes</td>
  	  		</tr>
  	  	</table>
  	  </div>



  	  <div class="col-md-12 col-sm-12 col-xs-12" id="bor" style="width: 100%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td colspan="5" style="text-align: center;"><b>Availability of Academic Stream</b></td>
  	  		</tr>

  	  		<tr>
  	  			<td style="text-align: center;"><b>Arts</b></td>
  	  			<td style="text-align: center;"><b>Science</b></td>
  	  			<td style="text-align: center;"><b>Commerce</b></td>
  	  			<td style="text-align: center;"><b>Vocational</b></td>
  	  			<td style="text-align: center;"><b>Other Stream</b></td>
  	  		</tr>

  	  		<tr>
  	  			<td style="text-align: center;">1-Yes</td>
  	  			<td style="text-align: center;">1-Yes</td>
  	  			<td style="text-align: center;">1-Yes</td>
  	  			<td style="text-align: center;">2-No</td>
  	  			<td style="text-align: center;">2-No</td>
  	  		</tr>
  	  	</table>
  	  </div>

  	  <div class="col-md-12 col-sm-12 col-xs-12" id="bor" style="width: 100%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td style="text-align: center;"><b>Teachers</b></td>
  	  		</tr>
  	  	</table>
  	  </div>



  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 50%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td colspan="6" style="text-align: center;"><b>Classes Taught</b></td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">1-Primary</td>
  	  			<td style="text-align: right;">12</td>
  	  			<td colspan="2">2-Up.Pr.</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>


  	  		<tr>
  	  			<td colspan="2">3-Pr. & Up.Pr.</td>
  	  			<td style="text-align: right;">0</td>
  	  			<td colspan="2">5-Sec. only</td>
  	  			<td style="text-align: right;">2</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">6-H Sec only.</td>
  	  			<td style="text-align: right;">13</td>
  	  			<td colspan="2">7-Up pri and Sec.</td>
  	  			<td style="text-align: right;">15</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">8-Sec and H Sec</td>
  	  			<td style="text-align: right;">5</td>
  	  			<td colspan="2">10- Pre-Primary Only.</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">11-Pre- Pri & Pri </td>
  	  			<td style="text-align: right;">0</td>
  	  			<td colspan="3"></td>
  	  		</tr>


  	  		<tr>
  	  			<td colspan="5">Teachers Aged above 55 </td>
  	  			<td colspan="1" style="text-align: right;">1</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="5">No. of Total Teacher Received Service Training</td>
  	  			<td colspan="1" style="text-align: right;">47</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="5">Total Teacher Involve in Non Teaching Assignment</td>
  	  			<td colspan="1" style="text-align: right;">37</td>
  	  		</tr>

  	  	</table>
  	  </div>

  	  <div class="col-md-6 col-sm-6 col-xs-6" id="bor" style="width: 50%; float: left;">
  	  	<table>
  	  		<tr>
  	  			<td colspan="2" style="text-align: center;"><b>Total</b></td>
  	  			<td colspan="2" style="text-align: center;">47</td>
  	  			<td></td>
  	  			<td></td>

  	  		</tr>

  	  		<tr>
  	  			<td colspan="3" style="text-align: center;"><b>Nature of Appointment</b></td>
  	  			<td colspan="3" style="text-align: center;"><b>Gender</b></td>
  	  		</tr>


  	  		<tr>
  	  			<td colspan="2">Regular</td>
  	  			<td style="text-align: right;">38</td>
  	  			<td colspan="2">Male</td>
  	  			<td style="text-align: right;">9</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Part-time</td>
  	  			<td style="text-align: right;">0</td>
  	  			<td colspan="2">Female</td>
  	  			<td style="text-align: right;">38</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="2">Contract</td>
  	  			<td style="text-align: right;">9</td>
  	  			<td colspan="2">Transgender</td>
  	  			<td style="text-align: right;">0</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="6" style="text-align: center;"><b>Academic Qualification</b></td>
  	  		</tr>


  	  		<tr>
  	  			<td colspan="2">Below Graduate</td>
  	  			<td style="text-align: right;">1</td>
  	  			<td colspan="2">Graduate</td>
  	  			<td style="text-align: right;">9</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="5">Post Graduate and Above</td>
  	  			<td colspan="1" style="text-align: right;">37</td>
  	  		</tr>

  	  		<tr>
  	  			<td colspan="5">Total Teacher Trained in Computer</td>
  	  			<td colspan="1" style="text-align: right;">47</td>
  	  		</tr>

  	  	</table>
  	  </div>


  	  <div class="col-md-12 col-sm-12 col-xs-12" id="bor" style="width: 100%; float: ;">
  	  	 <table>

  	  	 	<tr>
  	  	 		<td colspan="6" style="text-align: center;"><b>Teacher With Professional Qualification</b></td>
  	  	 	</tr>

  	  	 	<tr>
  	  	 		<td colspan="2">Diploma or Certificate in basic teachers’ training </td>
  	  	 		<td style="text-align:right;">4</td>
  	  	 		<td colspan="2">Bachelor of Elementary Education (B.El.Ed.) </td>
  	  	 		<td style="text-align:right;">5</td>
  	  	 	</tr>

  	  	 	<tr>
  	  	 		<td colspan="2">B.Ed. or Equivalent</td>
  	  	 		<td style="text-align:right;">29</td>
  	  	 		<td colspan="2">M.Ed. or Equivalent </td>
  	  	 		<td style="text-align:right;">3</td>
  	  	 	</tr>

  	  	 	<tr>
  	  	 		<td colspan="2">Other</td>
  	  	 		<td style="text-align:right;">3</td>
  	  	 		<td colspan="2">None</td>
  	  	 		<td style="text-align:right;">3</td>
  	  	 	</tr>

  	  	 	<tr>
  	  	 		<td colspan="2">Diploma/degree in special Education</td>
  	  	 		<td style="text-align:right;">0</td>
  	  	 		<td colspan="2">Pursuing any Relevant Professional Course</td>
  	  	 		<td style="text-align:right;">1</td>
  	  	 	</tr>

  	  	 </table>
  	  </div>



  	 
      
    </div>
    
    
</div>

</body>
</html>
